"use client"

import { useEffect, useState } from "react"

interface TypeWriterProps {
  words: string[]
  delay?: number
  className?: string
}

export function TypeWriter({ words, delay = 100, className = "" }: TypeWriterProps) {
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [currentText, setCurrentText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const word = words[currentWordIndex]

    const timer = setTimeout(
      () => {
        if (!isDeleting) {
          // Typing
          if (currentText !== word) {
            setCurrentText(word.slice(0, currentText.length + 1))
          } else {
            // Wait before starting to delete
            setTimeout(() => setIsDeleting(true), 1500)
          }
        } else {
          // Deleting
          if (currentText === "") {
            setIsDeleting(false)
            setCurrentWordIndex((prev) => (prev + 1) % words.length)
          } else {
            setCurrentText(word.slice(0, currentText.length - 1))
          }
        }
      },
      isDeleting ? delay / 2 : delay,
    )

    return () => clearTimeout(timer)
  }, [currentText, isDeleting, words, currentWordIndex, delay])

  return (
    <span className={`${className} inline-block min-w-[4ch]`}>
      {currentText}
      <span className="animate-pulse">|</span>
    </span>
  )
}


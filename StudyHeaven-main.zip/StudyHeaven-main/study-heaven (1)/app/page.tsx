import Image from "next/image"
import Link from "next/link"
import { ChevronDown, User, Facebook, Twitter, Youtube, Linkedin, ArrowUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { TypeWriter } from "./components/type-writer"

export default function CoursesPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Colorful%20Book%20Store%20Education%20Free%20Logo-0cPM0VGcoxTe0NdP7ZScW4pMzevcDp.png"
                alt="StudyHeaven Logo"
                width={50}
                height={50}
                className="rounded"
              />
              <div className="text-2xl font-bold">
                <span>Study</span>
                <span className="text-[#00B2FF]">Heaven</span>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-[#00B2FF] font-medium">
                HOME
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-[#00B2FF] font-medium">
                ABOUT
              </Link>
              <Link href="/courses" className="text-gray-700 hover:text-[#00B2FF] font-medium">
                COURSES
              </Link>
              <div className="relative group">
                <button className="flex items-center space-x-1 text-gray-700 hover:text-[#00B2FF] font-medium">
                  <span>PAGES</span>
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>
              <Link href="/faq" className="text-gray-700 hover:text-[#00B2FF] font-medium">
                FAQ
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-[#00B2FF] font-medium">
                CONTACT
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <Link href="/signin">
                <Button variant="ghost">Sign In</Button>
              </Link>
              <Link href="/signup">
                <Button className="bg-[#00B2FF] hover:bg-[#73bfff] text-white">Sign Up</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-[300px]">
        <Image
          src="https://media.istockphoto.com/id/1998218882/photo/teacher-in-class-explaining-something-to-a-group-of-students.webp?s=2048x2048&w=is&k=20&c=VPI8qK_Ml_DK8p8sF6W9AHONBlA1xf1W6vMGz9ZMuuk="
          alt="Students learning"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <h1 className="text-5xl font-bold mb-4">
            <TypeWriter
              words={["Welcome to StudyHeaven", "Start Learning Today", "Expand Your Skills", "Join Our Community"]}
              delay={150}
            />
          </h1>
          <div className="flex items-center space-x-2">
            <Link href="/" className="hover:text-[#00B2FF]">
              Home
            </Link>
            <span>/</span>
            <span>Courses</span>
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-gray-600 font-medium mb-2">CATEGORIES</h2>
          <div className="flex items-center justify-center space-x-4">
            <div className="w-12 h-[2px] bg-[#00B2FF]" />
            <h3 className="text-3xl font-bold text-gray-800">
              <TypeWriter
                words={["Popular Topics to Explore", "Start Your Journey", "Choose Your Path"]}
                delay={100}
                className="text-transparent bg-clip-text bg-gradient-to-r from-[#00B2FF] to-[#73bfff]"
              />
            </h3>
            <div className="w-12 h-[2px] bg-[#00B2FF]" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="aspect-video relative">
                <Image src="/assets/tml.jpg" alt={category.name} fill className="object-cover" />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <h4 className="text-white text-xl font-bold mb-2">{category.name}</h4>
                    <p className="text-gray-200">{category.courses} Courses</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1A1F3D] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Quick Links */}
            <div>
              <h3 className="text-2xl font-bold mb-6">Quick Link</h3>
              <ul className="space-y-4">
                <li>
                  <Link href="/about" className="hover:text-[#00B2FF]">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-[#00B2FF]">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-[#00B2FF]">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-[#00B2FF]">
                    Terms & Condition
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="hover:text-[#00B2FF]">
                    FAQs & Help
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-2xl font-bold mb-6">Contact</h3>
              <ul className="space-y-4">
                <li>123 Street, Bangalore, Karnataka</li>
                <li>+91 98039XXXXX</li>
                <li>studyheaven@gmail.com</li>
                <li className="flex space-x-4 pt-4">
                  <Link href="#" className="bg-[#00B2FF] p-2 rounded-full hover:bg-[#73bfff] transition-colors">
                    <Twitter className="w-5 h-5" />
                  </Link>
                  <Link href="#" className="bg-[#00B2FF] p-2 rounded-full hover:bg-[#73bfff] transition-colors">
                    <Facebook className="w-5 h-5" />
                  </Link>
                  <Link href="#" className="bg-[#00B2FF] p-2 rounded-full hover:bg-[#73bfff] transition-colors">
                    <Youtube className="w-5 h-5" />
                  </Link>
                  <Link href="#" className="bg-[#00B2FF] p-2 rounded-full hover:bg-[#73bfff] transition-colors">
                    <Linkedin className="w-5 h-5" />
                  </Link>
                </li>
              </ul>
            </div>

            {/* Newsletter */}
            <div>
              <h3 className="text-2xl font-bold mb-6">Subscribe to our Newsletter</h3>
              <p className="mb-6">
                Subscribe now and join our growing community of learners committed to lifelong education!
              </p>
              <div className="flex gap-2">
                <Input type="email" placeholder="Your email" className="bg-white text-gray-900" />
                <Button className="bg-[#00B2FF] hover:bg-[#73bfff]">Subscribe</Button>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-gray-700 flex justify-between items-center">
            <p>© StudyHeaven, All Right Reserved.</p>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="bg-[#00B2FF] p-3 rounded hover:bg-[#73bfff] transition-colors"
            >
              <ArrowUp className="w-5 h-5" />
            </button>
          </div>
        </div>
      </footer>
    </div>
  )
}

const categories = [
  {
    name: "Web Development",
    courses: 24,
    image: "/placeholder.svg?height=300&width=500&text=Web+Development",
  },
  {
    name: "Mobile Development",
    courses: 18,
    image: "/placeholder.svg?height=300&width=500&text=Mobile+Development",
  },
  {
    name: "Data Science",
    courses: 16,
    image: "/placeholder.svg?height=300&width=500&text=Data+Science",
  },
  {
    name: "UI/UX Design",
    courses: 12,
    image: "/placeholder.svg?height=300&width=500&text=UI/UX+Design",
  },
  {
    name: "Cloud Computing",
    courses: 15,
    image: "/placeholder.svg?height=300&width=500&text=Cloud+Computing",
  },
  {
    name: "Artificial Intelligence",
    courses: 20,
    image: "/placeholder.svg?height=300&width=500&text=AI",
  },
]


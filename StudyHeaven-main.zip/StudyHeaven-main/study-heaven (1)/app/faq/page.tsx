"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

const faqs = [
  {
    question: "What courses does StudyHeaven offer?",
    answer:
      "StudyHeaven offers a wide range of courses including Web Development, Mobile Development, Data Science, UI/UX Design, Cloud Computing, and Artificial Intelligence.",
  },
  {
    question: "How do I enroll in a course?",
    answer:
      "To enroll in a course, simply navigate to the course page, click on the 'Enroll' button, and follow the registration process. You may need to create an account if you haven't already.",
  },
  {
    question: "Are the courses self-paced or do they have specific start dates?",
    answer:
      "Most of our courses are self-paced, allowing you to learn at your own speed. However, some courses may have specific start dates for cohort-based learning. Check the individual course details for more information.",
  },
  {
    question: "Do I get a certificate upon completion of a course?",
    answer:
      "Yes, upon successful completion of a course, you will receive a digital certificate that you can share on your resume or social media profiles.",
  },
]

export default function FAQPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [question, setQuestion] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission logic here
    console.log("Question submitted:", { name, email, question })
    // Reset form fields
    setName("")
    setEmail("")
    setQuestion("")
  }

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h1>

        <div className="space-y-4 mb-12">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white shadow overflow-hidden rounded-md">
              <button
                className="w-full text-left px-4 py-5 sm:px-6 flex justify-between items-center focus:outline-none"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <h3 className="text-lg leading-6 font-medium text-gray-900">{faq.question}</h3>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-gray-500" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-500" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-4 pb-5 sm:px-6">
                  <p className="text-base text-gray-500">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="bg-white shadow overflow-hidden rounded-md p-6">
          <h2 className="text-2xl font-bold mb-4">Ask a Question</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="question">Your Question</Label>
              <Textarea
                id="question"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                required
                rows={4}
              />
            </div>
            <Button type="submit" className="w-full bg-[#00B2FF] hover:bg-[#73bfff]">
              Submit Question
            </Button>
          </form>
        </div>

        <div className="mt-8 text-center">
          <Link href="/" className="text-[#00B2FF] hover:underline">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  )
}

